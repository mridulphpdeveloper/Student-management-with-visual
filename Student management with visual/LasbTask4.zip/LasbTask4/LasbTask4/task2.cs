﻿using System;

public class ATM
{
    private int balance;

    public ATM(int initialBalance)
    {
        balance = initialBalance;
    }

    public bool Withdraw(int amount)
    {
        if (amount <= balance)
        {
            balance -= amount;
            return true;
        }
        else
        {
            return false;
        }
    }

    public int GetBalance()
    {
        return balance;
    }
}

public class User
{
    private string name;
    private int pin;
    private ATM atm;

    public User(string name, int pin, ATM atm)
    {
        this.name = name;
        this.pin = pin;
        this.atm = atm;
    }

    public bool Withdraw(int amount, int enteredPin)
    {
        if (enteredPin == pin)
        {
            return atm.Withdraw(amount);
        }
        else
        {
            return false;
        }
    }
}

public static void Main(string[] args)
{
    ATM atm = new ATM(1000);
    User user = new User("John Doe", 1234, atm);

    Console.WriteLine("Initial balance: " + atm.GetBalance());

    bool success = user.Withdraw(500, 1234);
    if (success)
    {
        Console.WriteLine("Withdrawal successful");
    }
    else
    {
        Console.WriteLine("Withdrawal failed");
    }

    Console.WriteLine("Remaining balance: " + atm.GetBalance());
}
