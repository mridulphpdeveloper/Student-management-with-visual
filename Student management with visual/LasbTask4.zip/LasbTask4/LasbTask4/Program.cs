﻿using System;

namespace LabTask4
{
    public class UniversityStudent
    {
        public void Register()
        {
            // code for Register method
        }

        public void Noit()
        {
            // code for Noit method
        }
    }

    public class CSharpStudent : UniversityStudent
    {
        public void Namestring()
        {
            // code for Namestring method
        }
    }

    public class GraderStudent : UniversityStudent
    {
        public static void Main(string[] args)
        {
            UniversityStudent student1 = new UniversityStudent();
            student1.Register();
            student1.Noit();

            CSharpStudent student2 = new CSharpStudent();
            student2.Register();
            student2.Noit();
            student2.Namestring();

            GraderStudent student3 = new GraderStudent();
            student3.Register();
            student3.Noit();
        }
    }

   


}
